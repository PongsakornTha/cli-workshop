# Intro to the Command Line — Workshop

Website: https://YOUR-USERNAME.github.io/cli-workshop/

Edit `docs/index.md` and push to `main`; the site rebuilds automatically.
